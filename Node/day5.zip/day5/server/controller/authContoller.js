
export const adddata=async(req,res)=>{


  try {
    console.log(req.body)
   const {name,courese}=req.body

  } catch (error) {
    console.log(error);
    
    
  }




}
