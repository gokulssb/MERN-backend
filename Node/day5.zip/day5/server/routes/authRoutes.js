import express from "express";
import { adddata } from "../controller/authContoller.js";


const authRoute = express.Router();

// http://localhost:5000/api/auth/useradd


authRoute.post("/useradd",adddata)


export default authRoute;